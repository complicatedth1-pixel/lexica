// stopwatch.js — Timer state, topic time tracking, PDF page time
// Owns: swElapsed, swStart, swTimer, swRunning, swSessionElapsed
// Reads: treeData, selectedChapterId, selectedTopicId (from editor.js)
// Reads: pdfMode, pdfViewerBook, pdfCurrentPage (from pdf.js)

'use strict';

let swElapsed = 0, swStart = null, swTimer = null, swRunning = false, swSessionElapsed = 0;
const swDisplay = document.getElementById('swDisplay');
const swStartStop = document.getElementById('swStartStop');

function swFormat(ms) {
  const s = Math.floor(ms/1000), h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
  if (h > 0) return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0');
  return String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0');
}

swStartStop.addEventListener('click', () => {
  if (!swRunning) {
    swStart = Date.now();
    swTimer = setInterval(() => { swDisplay.textContent = swFormat(swElapsed + (Date.now() - swStart)); }, 500);
    swRunning = true; swStartStop.textContent = '⏸'; swDisplay.classList.add('running');
  } else {
    const added = Date.now() - swStart; swElapsed += added; swSessionElapsed += added;
    clearInterval(swTimer); swRunning = false; swStartStop.textContent = '▶';
    swDisplay.classList.remove('running'); swDisplay.textContent = swFormat(swElapsed);
    if (pdfMode && pdfCurrentPage !== null) savePDFPageTime();
  }
});

document.getElementById('swReset').addEventListener('click', () => {
  if (swRunning) { swSessionElapsed += Date.now() - swStart; clearInterval(swTimer); swRunning = false; swStartStop.textContent = '▶'; swDisplay.classList.remove('running'); }
  swElapsed = 0; swSessionElapsed = 0; swStart = null; swDisplay.textContent = '00:00';
  if (pdfMode && pdfCurrentPage !== null) {
    if (!pdfViewerBook.pageTimes) pdfViewerBook.pageTimes = {};
    pdfViewerBook.pageTimes[pdfCurrentPage] = 0;
    saveBook(pdfViewerBook); showToast('Timer reset');
  }
});

function savePDFPageTime() {
  if (!pdfMode || !pdfViewerBook || pdfCurrentPage === null) return;
  if (!pdfViewerBook.pageTimes) pdfViewerBook.pageTimes = {};
  pdfViewerBook.pageTimes[pdfCurrentPage] = (pdfViewerBook.pageTimes[pdfCurrentPage] || 0) + swElapsed;
  pdfViewerBook.lastPage = pdfCurrentPage;
  saveBook(pdfViewerBook);
}

function loadPDFPageTime(pageNum) {
  if (!pdfMode || !pdfViewerBook || !pdfViewerBook.pageTimes) return 0;
  return pdfViewerBook.pageTimes[pageNum] || 0;
}

function saveStopwatchToTopic() {
  const tp = getSelectedTopic(); if (!tp) return;
  let sessionTime = swSessionElapsed;
  if (swRunning && swStart) sessionTime += Date.now() - swStart;
  if (sessionTime <= 0) return;
  if (!tp.timeSpent) tp.timeSpent = 0;
  tp.timeSpent += sessionTime;
  swSessionElapsed = 0;
  if (swRunning && swStart) swStart = Date.now();
  tp.wordCount = computeTopicWordCount(tp);
  saveAll();
}

function computeTopicWordCount(tp) {
  if (!tp) return 0;
  let text = '';
  (tp.sections||[]).forEach(sec => { if (sec.content) { const tmp = document.createElement('div'); tmp.innerHTML = sec.content; text += ' ' + tmp.textContent; } });
  text = text.trim();
  return text ? text.split(/\s+/).filter(Boolean).length : 0;
}

// Save time when switching topics
document.getElementById('chapterList').addEventListener('click', e => {
  const topicName = e.target.closest('.topic-name');
  if (topicName) {
    const tid = topicName.dataset.tid;
    if (tid && tid !== selectedTopicId) {
      if (swRunning && swStart) swSessionElapsed += Date.now() - swStart;
      saveStopwatchToTopic();
      clearInterval(swTimer); swRunning = false; swStart = null; swSessionElapsed = 0;
      swStartStop.textContent = '▶'; swDisplay.classList.remove('running');
      setTimeout(() => {
        const newTp = getSelectedTopic();
        swElapsed = (newTp && newTp.timeSpent) ? newTp.timeSpent : 0;
        swDisplay.textContent = swElapsed > 0 ? swFormat(swElapsed) : '00:00';
      }, 50);
    }
  }
}, true);

// Save time when going home
document.getElementById('homeLink').addEventListener('click', () => {
  if (!pdfMode) {
    if (swRunning && swStart) swSessionElapsed += Date.now() - swStart;
    saveStopwatchToTopic();
    clearInterval(swTimer); swRunning = false; swElapsed = 0; swStart = null; swSessionElapsed = 0;
    swStartStop.textContent = '▶'; swDisplay.textContent = '00:00'; swDisplay.classList.remove('running');
  }
}, true);

window.swFormat = swFormat;
window.saveStopwatchToTopic = saveStopwatchToTopic;
window.savePDFPageTime = savePDFPageTime;
window.loadPDFPageTime = loadPDFPageTime;
